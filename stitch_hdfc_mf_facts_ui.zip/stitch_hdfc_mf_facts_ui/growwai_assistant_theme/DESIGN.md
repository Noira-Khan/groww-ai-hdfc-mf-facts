---
name: GrowwAI Assistant Theme
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#3c4a43'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#6b7b72'
  outline-variant: '#bacac1'
  surface-tint: '#006c4f'
  primary: '#006c4f'
  on-primary: '#ffffff'
  primary-container: '#00d09c'
  on-primary-container: '#00533c'
  inverse-primary: '#2fe0aa'
  secondary: '#006c4f'
  on-secondary: '#ffffff'
  secondary-container: '#6ef7c6'
  on-secondary-container: '#007153'
  tertiary: '#565e74'
  on-tertiary: '#ffffff'
  tertiary-container: '#afb7d0'
  on-tertiary-container: '#40485d'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#59fdc5'
  primary-fixed-dim: '#2fe0aa'
  on-primary-fixed: '#002116'
  on-primary-fixed-variant: '#00513b'
  secondary-fixed: '#71fac8'
  secondary-fixed-dim: '#50ddad'
  on-secondary-fixed: '#002116'
  on-secondary-fixed-variant: '#00513b'
  tertiary-fixed: '#dae2fd'
  tertiary-fixed-dim: '#bec6e0'
  on-tertiary-fixed: '#131b2e'
  on-tertiary-fixed-variant: '#3f465c'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 40px
    fontWeight: '800'
    lineHeight: 48px
    letterSpacing: -0.03em
  headline-xl-mobile:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '800'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.06em
  caption:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system embodies the clear, accessible, and high-trust personality of modern consumer fintech. Designed for retail investors, first-time financial learners, and mutual fund researchers, the interface prioritizes utter lucidity, factuality, and reduced cognitive friction. The emotional posture is disciplined, reassuring, and approachable—counteracting the overwhelming jargon of financial compliance with crisp structure and calm white-space.

The design movement combines **Corporate Modern** with **High-Clarity Minimalist FinTech**:
- **Light & Pristine Canvas**: Ultra-clean surfaces featuring pure whites and subtle slate-tinted neutral fills that allow financial data and educational explanations to stand at the forefront.
- **Intentional Vivid Accents**: Signature mint and emerald greens serve as beacons of positivity, forward progression, and verified financial clarity.
- **Structured Conversational Elements**: Clear separation between prompt actions, suggestion pills, interactive query prompts, and authoritative, fact-grounded answer cards.

## Colors

The palette leverages a crisp light aesthetic tuned for high legibility, strict financial trust, and instant readability:

- **Primary (`#00D09C`) & Primary Dark (`#00B386`)**: The signature growth emerald/mint tone. Used for actionable highlights, user message bubbles, active state indicators, link hovers, and verification markers.
- **Dark Neutral & Typography (`#111827`, `#1E293B`, `#334155`)**: Deep slate and charcoal tones engineered for contrast against pure white cards and backgrounds, ensuring readability of complex regulatory paragraphs.
- **Surface & Backgrounds (`#FFFFFF`, `#F8FAFC`, `#F1F5F9`)**: Canvas backgrounds rely on `#F8FAFC`, while elevated conversational cards, prompt panels, and input trays rely on pristine `#FFFFFF`.
- **Structural Outlines (`#E2E8F0`, `#E5E7EB`)**: Precise, low-contrast hairline borders that delineate interactive questions and schema cards without visual clutter.
- **Status & Warning Accents**: Muted amber (`#F59E0B`) used for auxiliary source notices and fact-desk accents.

## Typography

The design system utilizes **Inter** across all typographic hierarchies. Known for its mechanical precision, tall x-height, and neutral optical rhythm, it provides maximum legibility for financial disclosures, dense numeric statements, and conversational interactions.

- **Primary Headings**: Rendered in weight 800 with tight negative tracking (`-0.03em`). Two-tone styling is applied to major hero headlines: charcoal black transitioning into vibrant signature green on terminal words.
- **Section & Category Eyebrows**: Rendered using `label-sm` in bold uppercase with expanded tracking (`0.06em`) in green or amber to demarcate verification categories (e.g., `ANSWER FROM OFFICIAL SOURCES`).
- **Body & Explanatory Text**: Maintained at comfortable line heights (1.5x–1.6x) in muted charcoal (`#334155`) to facilitate effortless scanning of multi-sentence regulatory answers.

## Elevation & Depth

Visual hierarchy relies on crisp surface separation, border definition, and light ambient shadows:

- **Flat Border Grounding**: Cards and suggestion tiles rest in flat space bound by crisp `1px` borders (`#E2E8F0`). Contrast is generated through pure white card fills resting against `#F8FAFC` canvas backgrounds.
- **Interactive Floating Dock**: The bottom interaction bar and top navigation utilize subtle diffused elevation: `box-shadow: 0 4px 20px -2px rgba(15, 23, 42, 0.05)`.
- **Card Hover States**: Interactive tiles (e.g., sample question cards) transition subtly on hover with border darkening to `#CBD5E1` and an elevation shift: `box-shadow: 0 4px 12px -2px rgba(0, 208, 156, 0.08)`.
- **Glassmorphic Floating Headers**: Sticky navigation bars employ `backdrop-filter: blur(8px)` with semi-transparent white background (`rgba(255, 255, 255, 0.92)`) bounded by a subtle bottom divider.

## Shapes

The shape system employs roundedness level 2, balancing friendly modern fintech curves with disciplined utility:

- **Base Radius (0.5rem / 8px)**: Applied to small inputs, category tags, interactive chips, and internal action buttons.
- **Card Radius (1rem / 16px - `rounded-lg`)**: Applied to official answer containers, question prompt tiles, and search input shells.
- **Large Container Radius (1.5rem / 24px - `rounded-xl`)**: Applied to prominent chat bubbles, empty-state containers, and modal sheets.
- **Pill Badges (`9999px`)**: Reserved for system status indicators, conversational prompt bubbles, filter tags, and circular send/action icon buttons.

## Components

### Buttons & Quick Actions
- **Primary Action (Send/Submit)**: Circular or rounded pill container with `#00D09C` background, solid white icon, hovering to `#00B386`.
- **Dashed Suggestion Action**: Outlined button with `1.5px dashed #00D09C`, soft mint background tint (`#F0FDF4`), and `#00875A` text for follow-up prompts.
- **Icon Buttons**: Light ghost buttons (`#F8FAFC`) with subtle `#E2E8F0` border and slate icons for secondary controls (theme toggle, edit pencil).

### Suggestion Chips & Scheme Pills
- **Filter Chips**: Pill-shaped horizontal selector buttons with white fill, `1px solid #E2E8F0`, deep slate text (`#1E293B`), transitioning on active selection to solid dark background (`#0F172A`) or primary green highlight.
- **Tag Badges**: Pill tags with subtle cool-gray fills (`#F1F5F9`), tiny text (`11px`), and slate typography (`#64748B`) denoting categories and indexing timestamps.

### Chat & Response Cards
- **User Question Bubble**: Right-aligned, colored with `#00B386` (or `#00D09C`), featuring crisp white typography and rounded corners with a sharper corner anchor.
- **Fact-Desk Answer Card**: Left-aligned, full-width structured container with pure white background, `1px solid #E2E8F0`, and `rounded-2xl` corners.
  - *Header*: Features an amber/emerald bullet, followed by uppercase tracking label `ANSWER FROM OFFICIAL SOURCES`.
  - *Body*: Clear body text with a dedicated hairline divider (`#F1F5F9`) separating sources.
  - *Source Citations*: Underlined/bold emerald green text with an external link indicator arrow (`↗`).

### Prompt Suggestion Tiles
- Rectangular card components with subtle `1px solid #E2E8F0` border, `rounded-xl` geometry, and generous internal padding (`1rem`).
- Features dark slate body text and a small angled arrow icon (`↗`) locked to the bottom-right corner in primary green (`#00D09C`).

### Query Input Dock
- Sticky floating bottom bar featuring a pill or soft-rounded enclosure (`rounded-2xl`), ambient low-intensity shadow, placeholder text in `#94A3B8`, and integrated inline action buttons (attachment/edit icon and primary green submit circle).
- Accompanying disclaimer text centered directly below in fine caption styling (`11px`, `#94A3B8`).